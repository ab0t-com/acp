# ACP — Agent Coordination Protocol

<p align="center">
  <img src="assets/acp-hero.png" alt="ACP — where AI agents work together" width="1215" height="472" style="max-width: 100%; height: auto; border-radius: 16px;" />
</p>

<p align="center">
  <b>Where AI agents work together.</b><br/>
  A shared filesystem and a comms line for multi-agent systems — self-hosted, multi-tenant, highly available.
</p>

<p align="center">
  <a href="LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-7C6CF0"></a>
  <img alt="release v0.2.3" src="https://img.shields.io/badge/release-v0.2.3-2DD4BF">
  <img alt="protocol acp/1" src="https://img.shields.io/badge/protocol-acp%2F1-FF9466">
</p>

A self-hostable system that gives multiple AI agent harnesses — on different machines —
a **shared filesystem** and a **comms line**, so they can collaborate on projects, specs,
and problems. Small Go daemon + CLI + MCP bridge. TLS, multi-tenant, highly available.

> This is the **public client repo**: install scripts, prebuilt release binaries, docs,
> and skills. The implementation source is maintained privately; releases are published
> here. Licensed **MIT**. Commercial/enterprise: see `ENTERPRISE.md` / https://ab0t.com.

## Install

```bash
curl -fsSL https://raw.githubusercontent.com/ab0t-com/acp/main/install.sh | bash
# installs: acp (CLI), coordd (daemon), acp-mcp (MCP bridge) -> ~/.local/bin
acp version
```

Just the client: `ACP_BINS=acp curl -fsSL .../install.sh | bash`. Specific version:
`ACP_VERSION=vX.Y.Z`. Custom dir: `ACP_INSTALL_DIR=/usr/local/bin`.

Already installed? `acp update` fetches the latest release, verifies its checksum, and swaps
your binaries in place (`--check` to just see if you're behind; `--version vX.Y.Z` to pin).

## Run with Docker

Prefer containers? One command gives you a full ACP authority:

```bash
docker run -d --name coordd --restart on-failure:5 -p 8443:8443 -v acp-data:/data ab0tcom/acp:latest
```

Shared filesystem, comms, live co-editing, presence, HA-ready — in a single small image
(`linux/amd64` + `arm64`). Your token, TLS certificate, and state all live in the `acp-data`
volume, so upgrades are just `docker pull` + recreate, with nothing lost.

Want **server DB mode (ACPDB)** — the same protocol backed by an embedded database for bounded, flat
memory at scale? Same command, the `:server` tag (it runs `coordd-server` for you):

```bash
docker run -d --name acpdb --restart on-failure:5 -p 8443:8443 -v acpdb-data:/data ab0tcom/acp:server
```

Grab the auto-generated token and point any client at it:

```bash
docker exec coordd cat /data/token
```

Pin a version with `ab0tcom/acp:v0.2.3`. Exposing it beyond localhost? Add `-hosts <your-host>` so
the certificate trusts that name. **Full walkthrough — TLS, configuration, docker-compose,
clustering — in [docs/DOCKER.md](docs/DOCKER.md).**

## What you get

- **Shared filesystem** — content-addressed; `acp push` / `acp pull` with 3-way merge.
- **Live co-editing** — `acp crdt sync` lets agents edit the *same* file and auto-merge (CRDT).
- **Comms** — directed mailbox (`send`/`inbox`) + a totally-ordered event log (`watch`).
- **Live presence** — ephemeral awareness (cursors, typing, status) that self-expires in seconds and never touches durable storage; optional WebSocket.
- **Safe concurrency** — TTL leases with fencing tokens; never lose work.
- **Recover from anything** — every version is retained; `acp history` / `acp restore` undo a wrong overwrite or delete as a normal forward commit, and a named `acp checkpoint` pins a known-good state.
- **Can't mass-delete by accident** — a commit that would wipe a large share of the tree is refused until you confirm the exact counts (`--confirm-bulk`), and an ordinary writer token can't land a bulk change at all — a runaway loop can't wreck the workspace.
- **Multi-tenant** — isolated **spaces** on one daemon; per-agent identity + roles.
- **HA** — run a 3-node **Raft** cluster (auto failover); **mTLS** between nodes; **encryption at rest**.
- **Storage modes** — file-backed by default, or **server DB mode (ACPDB)**: `coordd-server` embeds a real database for bounded, flat memory at scale. Same protocol, lossless conversion either way, no sidecar — *in server mode, ACP is the database*. → [docs/STORAGE-MODES.md](docs/STORAGE-MODES.md)
- **MCP bridge** — `acp-mcp` exposes ACP as tools to any MCP harness (Claude Code, Codex).

## Capabilities & extensions

Every daemon advertises what it supports in `/v1/healthz`'s `capabilities` array, so clients
can feature-detect instead of trial-and-erroring requests:

- `channels` — pub/sub on named channels with wildcard (`*`) topic filtering.
- `batchevents` — atomic multi-event append in one call.
- `crdtjson` — structured (JSON) CRDT documents, in addition to text CRDT sync.
- `crdtjson-move` — identity-preserving `mv` op for the JSON CRDT: reorder/relocate a node or array element without losing a peer's concurrent edit to it (safe drag-to-reorder, move-between-columns, reparent).
- `scopedtokens` — narrower-than-admin token grants.
- `scopedtokens.read` — confine a token to a subtree for **reads** too, not just writes; an out-of-scope path is indistinguishable from a missing one (no existence oracle).
- `history` — retained version history + restore/checkpoint: undo a wrong overwrite or delete as a forward commit (nothing re-uploaded; retained data is pinned against GC).
- `bulkguard` — a commit that would delete/overwrite a large share of the tree is refused (`428`) until the exact counts are confirmed; ordinary writer tokens are denied bulk changes by default.
- `acpuri` — one-string `acp://host/space/path` addressing, signed + expiring tokenless share links, and an optional read-only `/.well-known/acp` discovery document.
- `quotas` — per-space resource limits.
- `tenancy`, `tenancy.subscope` — scoped tokens + quotas + sub-scope project labels within a space (least-privilege; a space remains the only hard isolation boundary).
- `awareness`, `awareness-ws` — live, self-expiring presence (cursors, typing, status), never written to durable storage; optional WebSocket transport with a 15 Hz server-side coalescing tick.

Extension proposals live in [rfc/](rfc/) as RFC-2119 documents; a capability only appears in
`healthz` once its extension is accepted and implemented.

## Quickstart

```bash
# 1) run a daemon (any host both agents can reach)
coordd -addr :8443 -data ./acp-data -hosts <host>,127.0.0.1
#    prints a shared token (acp-data/token) and a pinned cert (acp-data/cert.pem)

# 2) configure a client profile (typed config in ~/.acp)
acp config init
acp config set prod server=https://<host>:8443 token=<token> cert=/path/cert.pem agent=claudeA
acp config use prod
acp who                                   # see who's online

# 3) collaborate
acp pull ./workspace                      # get shared files
acp send --to codexB --subject hi --body "you backend, me frontend"
acp crdt sync spec.md spec.md             # co-edit one file, auto-merges
```

Full client guide: [docs/](docs/) and the **acp-client** skill in [Skills/](Skills/).
HA deploy: **acp-cluster** skill. Operations: **acp-operations** skill.

## Build on it — TypeScript / JavaScript SDK

Prefer code to the CLI? [`@ab0t/acp`](https://www.npmjs.com/package/@ab0t/acp) talks to a daemon over
the same `acp/1` wire — Node ≥ 20 and evergreen browsers, **zero runtime dependencies**.

```bash
npm install @ab0t/acp
```

```js
import { Client } from "@ab0t/acp";
const c = new Client({ baseUrl: "https://<host>:8443", token: "<token>", agent: "app-1" });
await c.append({ action: "run.start", entity: "job/1" });      // ordered event log
const { hash, size } = await c.putBlob("# hello\n");            // content-addressed file
await c.send({ to: "worker-2", type: "inform", subject: "hi", body: "up" });  // mailbox
```

The same API runs in the browser, plus CRDT co-editing, live presence, and auto-reconnecting agent
loops (`followForever`, `withLease`). Full quickstart + API reference on
[npm](https://www.npmjs.com/package/@ab0t/acp). A Go SDK with the same interface contract is available
for partners.

## Docs

- [docs/API_REFERENCE.md](docs/API_REFERENCE.md) — the wire API.
- [docs/OPERATIONS.md](docs/OPERATIONS.md) — deploy, secure, cluster, back up, troubleshoot.
- [docs/DOCKER.md](docs/DOCKER.md) — run the daemon as a container (Docker Hub image, compose, TLS).
- [docs/THREAT_MODEL.md](docs/THREAT_MODEL.md) — security model.
- [docs/AWARENESS.md](docs/AWARENESS.md) — **live presence** (ext-9): cursors, typing, status over HTTP or WebSocket.
- [docs/STORAGE-MODES.md](docs/STORAGE-MODES.md) — **storage modes**: file-backed default vs server DB mode (ACPDB) — crossover, memory tuning, lossless migration.
- [rfc/acp-1.txt](rfc/acp-1.txt) — **the full protocol specification** (RFC-style, normative for `acp/1`).
- [rfc/acp-ext-1-channels-groups-pubsub.txt](rfc/acp-ext-1-channels-groups-pubsub.txt) — **extension proposal**: channels, groups & topic-filtered pub/sub (additive to `acp/1`).
- [Skills/](Skills/) — agent skills: acp-client, acp-operations, acp-cluster.
- [examples/](examples/) — quickstart walkthroughs.

## License

MIT — see [LICENSE](LICENSE). Built by [ab0t-com](https://ab0t.com).
